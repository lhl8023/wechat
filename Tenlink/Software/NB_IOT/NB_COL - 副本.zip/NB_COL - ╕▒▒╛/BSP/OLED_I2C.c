/************************************************************************************
*  Copyright (c), 2014, HelTec Automatic Technology co.,LTD.
*            All rights reserved.
*
* Http:    www.heltec.cn
* Email:   cn.heltec@gmail.com
* WebShop: heltec.taobao.com
*
* File name: OLED_I2C.c
* Project  : HelTec.uvprij
* Processor: STM32F103C8T6
* Compiler : MDK fo ARM
* 
* Author : С��
* Version: 1.00
* Date   : 2014.4.8
* Email  : hello14blog@gmail.com
* Modification: none
* 
* Description:128*64�����OLED��ʾ�������ļ����������ڻ����Զ���(heltec.taobao.com)��SD1306����IICͨ�ŷ�ʽ��ʾ��
*
* Others: none;
*
* Function List:
*	1. void I2C_Configuration(void) -- ����CPU��Ӳ��I2C
* 2. void I2C_SendByte(uint8_t addr,uint8_t data) -- ��Ĵ�����ַдһ��byte������
* 3. void WriteCmd(unsigned char I2C_Command) -- д����
* 4. void WriteDat(unsigned char I2C_Data) -- д����
* 5. void OLED_Init(void) -- OLED����ʼ��
* 6. void OLED_SetPos(unsigned char x, unsigned char y) -- ������ʼ������
* 7. void OLED_Fill(unsigned char fill_Data) -- ȫ�����
* 8. void OLED_CLS(void) -- ����
* 9. void OLED_ON(void) -- ����
* 10. void OLED_OFF(void) -- ˯��
* 11. void OLED_ShowStr(unsigned char x, unsigned char y, unsigned char ch[], unsigned char TextSize) -- ��ʾ�ַ���(�����С��6*8��8*16����)
* 12. void OLED_ShowCN(unsigned char x, unsigned char y, unsigned char N) -- ��ʾ����(������Ҫ��ȡģ��Ȼ��ŵ�codetab.h��)
* 13. void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[]) -- BMPͼƬ
*
* History: none;
*
*************************************************************************************/

#include "OLED_I2C.h"
#include "delay.h"
#include "codetab.h"

#define IIC_AHB2_CLK        RCC_APB2Periph_GPIOB
#define IIC_DATA_PIN        GPIO_Pin_5
#define IIC_SCK_PIN        	GPIO_Pin_6
#define IIC_DATA_PORT       GPIOB
#define IIC_SCK_PORT        GPIOB

#define IIC_DATA_H()        GPIO_SetBits(IIC_DATA_PORT, IIC_DATA_PIN)                  //����DATA������
#define IIC_DATA_L()        GPIO_ResetBits(IIC_DATA_PORT, IIC_DATA_PIN)                //����DATA������
#define IIC_DATA_R()        GPIO_ReadInputDataBit(IIC_DATA_PORT, IIC_DATA_PIN)         //��DATA������

#define IIC_SCK_H()        	GPIO_SetBits(IIC_SCK_PORT, IIC_SCK_PIN)                    //����SCKʱ����
#define IIC_SCK_L()        	GPIO_ResetBits(IIC_SCK_PORT, IIC_SCK_PIN)                  //����SCKʱ����
#define IIC_SCK_R()        	GPIO_ReadInputDataBit(IIC_SCK_PORT, IIC_SCK_PIN)         	//��SCK������

#define TWI_SCL_HIGH()   		IIC_SCK_H()
#define TWI_SCL_LOW()    		IIC_SCK_L()
#define TWI_SDA_HIGH()   		IIC_DATA_H()
#define TWI_SDA_LOW()    		IIC_DATA_L()
#define TWI_SDA_INPUT()  		IIC_DATAIn()
#define TWI_SCL_INPUT()  		IIC_SCKIn()
#define TWI_SDA_OUTPUT() 		IIC_DATAOut()
#define TWI_SCL_OUTPUT() 		IIC_SCKOut()
/*lint -restore */

#define TWI_SDA_READ() 			IIC_DATA_R()                     	/*!< Reads current state of SDA */
#define TWI_SCL_READ() 			IIC_SCK_R()                    	/*!< Reads current state of SCL */

#define TWI_DELAY() 				IIC_Dly() 	


void IIC_Dly(void)
{
	u16 i;
	for(i = 1; i > 0; i--);
}

void I2C_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;        
	//��ʼ��SHT10����ʱ��
	RCC_APB2PeriphClockCmd(IIC_AHB2_CLK | RCC_APB2Periph_AFIO,ENABLE);
	       
	GPIO_InitStructure.GPIO_Pin = IIC_DATA_PIN | IIC_SCK_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(IIC_DATA_PORT, &GPIO_InitStructure);	
	GPIO_Init(IIC_SCK_PORT, &GPIO_InitStructure);
	
	TWI_SDA_HIGH();
	TWI_SCL_HIGH();
}

void IIC_DATAOut(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//PD0 DATA �������        
	GPIO_InitStructure.GPIO_Pin = IIC_DATA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;         
	GPIO_Init(IIC_DATA_PORT, &GPIO_InitStructure);
}

void IIC_DATAIn(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//PD0 DATA ��������  �������û�н�����������Ҫ����Ϊ��������        
	GPIO_InitStructure.GPIO_Pin = IIC_DATA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(IIC_DATA_PORT, &GPIO_InitStructure);
}

void IIC_SCKOut(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//PD0 DATA �������        
	GPIO_InitStructure.GPIO_Pin = IIC_SCK_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;         
	GPIO_Init(IIC_SCK_PORT, &GPIO_InitStructure);
}

void IIC_SCKIn(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//PD0 DATA ��������  �������û�н�����������Ҫ����Ϊ��������        
	GPIO_InitStructure.GPIO_Pin = IIC_SCK_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(IIC_SCK_PORT, &GPIO_InitStructure);
}

static uint8_t I2C_Start(void)
{
	TWI_SDA_OUTPUT();
	TWI_DELAY();
	TWI_SDA_HIGH();
	TWI_DELAY();
	TWI_SCL_HIGH();
	TWI_DELAY();
	TWI_SDA_LOW();
	TWI_DELAY();
	TWI_SCL_LOW();
	TWI_DELAY();
	
	return 1;
}

static void I2C_Stop(void)
{
	TWI_SDA_OUTPUT();
	TWI_DELAY();
	TWI_SCL_LOW();
	TWI_DELAY();
	TWI_SDA_LOW();
	TWI_DELAY();
	TWI_SCL_HIGH();
	TWI_DELAY();
	TWI_SDA_HIGH();
	TWI_DELAY();
}

static void I2C_Ack(void)
{
	TWI_SCL_LOW();
	TWI_DELAY();
	TWI_SDA_OUTPUT();
	TWI_SDA_LOW();
	TWI_DELAY();
	TWI_SCL_HIGH();
	TWI_DELAY();
	TWI_SCL_LOW();
	TWI_DELAY();
}

static void I2C_NoAck(void)
{
	TWI_SCL_LOW();
	TWI_DELAY();
	TWI_SDA_OUTPUT();
	TWI_SDA_HIGH();
	TWI_DELAY();
	TWI_SCL_HIGH();
	TWI_DELAY();
	TWI_SCL_LOW();
	TWI_DELAY();
}

static uint8_t I2C_WaitAck(void)
{
	uint16_t timeout = 0;
	
	TWI_SCL_LOW();
	TWI_DELAY();
	TWI_SDA_INPUT();	
	TWI_DELAY();
	TWI_SCL_HIGH();
	TWI_DELAY();
	
	while(TWI_SDA_READ())
	{
		timeout++;
		if(timeout > 250)
		{
			I2C_Stop();
			return 0;
		}
		TWI_DELAY();
	}
	TWI_SCL_LOW();
	
	return 1;
}

/**/

static void I2C_SendByte(uint8_t byte)
{
	uint8_t i = 8;
	TWI_SDA_OUTPUT();
	TWI_DELAY();
	TWI_SCL_LOW();
	TWI_DELAY();
	while (i--) 
	{
		if (byte & 0x80)
			TWI_SDA_HIGH();
		else
		   TWI_SDA_LOW();
		TWI_DELAY();
		byte <<= 1;
		TWI_SCL_HIGH();
		TWI_DELAY();
		TWI_SCL_LOW();
		TWI_DELAY();
	}
}

void IIC_WriteByte(u8 data)
{
      u8 i;
    IIC_DATAOut();
    for(i=0;i<8;i++)
    {
        IIC_SCK_L();
        DelayUs(2);
        if(data & 0x80)     //MSB,�Ӹ�λ��ʼһλһλ����
            IIC_DATA_H();
        else
            IIC_DATA_L();
        IIC_SCK_H();
        DelayUs(2);
        IIC_SCK_L();
        data<<=1;

    }
}

void WriteCmd(unsigned char command)//д����
{
    I2C_Start();
    IIC_WriteByte(0x78);//OLED��ַ
    I2C_WaitAck();
    IIC_WriteByte(0x00);//�Ĵ�����ַ
    I2C_WaitAck();
    IIC_WriteByte(command);
    I2C_WaitAck();
    I2C_Stop();
}

void WriteDat(unsigned char data)//д����
{
    I2C_Start();
    IIC_WriteByte(0x78);//OLED��ַ
    I2C_WaitAck();
    IIC_WriteByte(0x40);//�Ĵ�����ַ
    I2C_WaitAck();
    IIC_WriteByte(data);
    I2C_WaitAck();
    I2C_Stop();
}

void OLED_Init(void)
{
	DelayMs(100); //�������ʱ����Ҫ
	
	WriteCmd(0xAE); //display off
	WriteCmd(0x20);	//Set Memory Addressing Mode	
	WriteCmd(0x10);	//00,Horizontal Addressing Mode;01,Vertical Addressing Mode;10,Page Addressing Mode (RESET);11,Invalid
	WriteCmd(0xb0);	//Set Page Start Address for Page Addressing Mode,0-7
	WriteCmd(0xc8);	//Set COM Output Scan Direction
	WriteCmd(0x00); //---set low column address
	WriteCmd(0x10); //---set high column address
	WriteCmd(0x40); //--set start line address
	WriteCmd(0x81); //--set contrast control register
	WriteCmd(0xff); //���ȵ��� 0x00~0xff
	WriteCmd(0xa1); //--set segment re-map 0 to 127
	WriteCmd(0xa6); //--set normal display
	WriteCmd(0xa8); //--set multiplex ratio(1 to 64)
	WriteCmd(0x3F); //
	WriteCmd(0xa4); //0xa4,Output follows RAM content;0xa5,Output ignores RAM content
	WriteCmd(0xd3); //-set display offset
	WriteCmd(0x00); //-not offset
	WriteCmd(0xd5); //--set display clock divide ratio/oscillator frequency
	WriteCmd(0xf0); //--set divide ratio
	WriteCmd(0xd9); //--set pre-charge period
	WriteCmd(0x22); //
	WriteCmd(0xda); //--set com pins hardware configuration
	WriteCmd(0x12);
	WriteCmd(0xdb); //--set vcomh
	WriteCmd(0x20); //0x20,0.77xVcc
	WriteCmd(0x8d); //--set DC-DC enable
	WriteCmd(0x14); //
	WriteCmd(0xaf); //--turn on oled panel
}

void OLED_SetPos(unsigned char x, unsigned char y) //������ʼ������
{ 
	WriteCmd(0xb0+y);
	WriteCmd(((x&0xf0)>>4)|0x10);
	WriteCmd((x&0x0f)|0x01);
}

void OLED_Fill(unsigned char fill_Data)//ȫ�����
{
	unsigned char m,n;
	for(m=0;m<8;m++)
	{
		WriteCmd(0xb0+m);		//page0-page1
		WriteCmd(0x00);		//low column start address
		WriteCmd(0x10);		//high column start address
		for(n=0;n<=130;n++)
			{
				WriteDat(fill_Data);
			}
	}
}

void OLED_ClearBox(unsigned char x0,unsigned char y,unsigned char x1)
{
  WriteCmd(0xb0+y);		//page0-page1
  WriteCmd(0x00);		//low column start address
  WriteCmd(0x10);		//high column start address
  
  for(;x0<=x1;x0++)
  {
    WriteDat(0X00);
  }
}

void OLED_DrawBox(unsigned char x0,unsigned char y,unsigned char x1)
{
  unsigned int i;
  WriteCmd(0xb0+y);		//page0-page1
  WriteCmd(0x00);		//low column start address
  WriteCmd(0x10);		//high column start address
  
  for(i=88;i<=96;i++)
  {
    WriteDat(0X7E);
  }
}

void OLED_DrawLineX(unsigned char x0,unsigned char y,unsigned char x1,unsigned int line)
{
  WriteCmd(0xb0+y);		//page0-page1
  WriteCmd(0x00);		//low column start address
  WriteCmd(0x10);		//high column start address
  
  for(;x0<=x1;x0++)
  {
    switch(line)
    {
    case 0:
      WriteDat(0X01);                     //������1��
      break;
    case 1:
      WriteDat(0X02);                     //������2��
      break;
    case 2:
      WriteDat(0X04);                     //������3��
      break;
    case 3:
      WriteDat(0X08);                     //������4��
      break;
    case 4:
      WriteDat(0X10);                     //������5��
      break;
    case 5:
      WriteDat(0X20);                     //������6��
      break;
    case 6:
      WriteDat(0X40);                     //������7��
      break;
    case 7:
      WriteDat(0X80);                     //������8��      
      break;
    }
  }
}

void OLED_DrawLineXbox(unsigned char x0,unsigned char x1,unsigned int line)
{
  int i=0;
  int full=0;
  full=line/8;
  line=line%8;
  
    WriteCmd(0xb0+4);		//page0-page1
    WriteCmd(0x00);		//low column start address
    WriteCmd(0x10);		//high column start address
    
    /*switch(full)
    {
    case 0:
    case 1:
      OLED_DrawBox(x0,5,x1);
    case 2:
      OLED_DrawBox(x0,4,x1);
    case 3:
      OLED_DrawBox(x0,3,x1);
    case 4:
      OLED_DrawBox(x0,2,x1);
    case 5:
      OLED_DrawBox(x0,1,x1);      
    }  */
  
  for(i=x0;i<=x1;i++)
  {
    OLED_DrawLineX(x0,4,x1,line);
  }
}

void OLED_DrawZpre(unsigned char x0,unsigned char y,unsigned char x1,unsigned int line)
{
  while((5-y)>=0)
  {
    OLED_DrawBox(x0,y,x1);
    y++;
  }
}


void OLED_DrawZplus(unsigned char x0,unsigned char y,unsigned char x1,unsigned int line)
{
  while(line>0)
  {
    OLED_DrawLineX(x0,y,x1,line);
    line--;
  }
}

void OLED_DrawPoint(unsigned char x,unsigned char y)
{
  
}

void OLED_CLS(void)//����
{
	OLED_Fill(0x00);
}

//--------------------------------------------------------------
// Prototype      : void OLED_ON(void)
// Calls          : 
// Parameters     : none
// Description    : ��OLED�������л���
//--------------------------------------------------------------
void OLED_ON(void)
{
	WriteCmd(0X8D);  //���õ�ɱ�
	WriteCmd(0X14);  //������ɱ�
	WriteCmd(0XAF);  //OLED����
}

//--------------------------------------------------------------
// Prototype      : void OLED_OFF(void)
// Calls          : 
// Parameters     : none
// Description    : ��OLED���� -- ����ģʽ��,OLED���Ĳ���10uA
//--------------------------------------------------------------
void OLED_OFF(void)
{
	WriteCmd(0X8D);  //���õ�ɱ�
	WriteCmd(0X10);  //�رյ�ɱ�
	WriteCmd(0XAE);  //OLED����
}

void OLED_ShowBChar(unsigned char x,unsigned char y,unsigned char A,unsigned char size)
{
  unsigned char c=0,i=0;
  switch(size)
  {
  case 1:
    {
      c=A-32;
      if(x>126)
      {
        x=0;
        y++;
      }
      OLED_SetPos(x,y);
      for(i=0;i<6;i++)
      {
        WriteDat(F6x8[c][i]);
      }
    }break;
    
  case 2:
    {
      c=A;
      if(x > 120)
      {
        x = 0;
        y++;
      }
      OLED_SetPos(x,y);
      for(i=0;i<8;i++)
        WriteDat(F8X16[c*16+i]);
      OLED_SetPos(x,y+1);
      for(i=0;i<8;i++)
        WriteDat(F8X16[c*16+i+8]);
      x += 8;
    }break;
  case 3:
    {
      c=9;
      if(x > 120)
      {
        x = 0;
        y++;
      }
      OLED_SetPos(x,y);
      for(i=0;i<16;i++)
        WriteDat(F16X40[c*80+i]);
      OLED_SetPos(x,y+1);
      for(i=0;i<16;i++)
        WriteDat(F16X40[c*80+i+16]);
      OLED_SetPos(x,y+2);
      for(i=0;i<16;i++)
        WriteDat(F16X40[c*80+i+32]);
      OLED_SetPos(x,y+3);
      for(i=0;i<16;i++)
        WriteDat(F16X40[c*80+i+48]);
      OLED_SetPos(x,y+4);
      for(i=0;i<16;i++)
        WriteDat(F16X40[c*80+i+64]);
      x += 16;
    }break;
  }
}

void OLED_ShowChar(unsigned char x,unsigned char y,unsigned char l,unsigned char size)
{
  unsigned char c=0,i=0;
  switch(size)
  {
  case 1:
    {
      c=l-32;
      if(x>126)
      {
        x=0;
        y++;
      }
      OLED_SetPos(x,y);
      for(i=0;i<6;i++)
      {
        WriteDat(F6x8[c][i]);
      }
    }break;
    
  case 2:
    {
      c=l;
      if(x > 120)
      {
        x = 0;
        y++;
      }
      OLED_SetPos(x,y);
      for(i=0;i<8;i++)
        WriteDat(F8X16[c*16+i]);
      OLED_SetPos(x,y+1);
      for(i=0;i<8;i++)
        WriteDat(F8X16[c*16+i+8]);
      x += 8;
    }break;
      
  }
}

//--------------------------------------------------------------
// Prototype      : void OLED_ShowChar(unsigned char x, unsigned char y, unsigned char ch[], unsigned char TextSize)
// Calls          : 
// Parameters     : x,y -- ��ʼ������(x:0~127, y:0~7); ch[] -- Ҫ��ʾ���ַ���; TextSize -- �ַ���С(1:6*8 ; 2:8*16)
// Description    : ��ʾcodetab.h�е�ASCII�ַ�,��6*8��8*16��ѡ��
//--------------------------------------------------------------
void OLED_ShowStr(unsigned char x, unsigned char y, unsigned char ch[], unsigned char TextSize)
{
	unsigned char c = 0,i = 0,j = 0;
        int n=0;
	switch(TextSize)
	{
		case 1:
		{
			while(ch[j] != '\0')
			{
				c = ch[j] - 32;
				if(x > 126)
				{
					x = 0;
					y++;
				}
				OLED_SetPos(x,y);
				for(i=0;i<6;i++)
					WriteDat(F6x8[c][i]);
				x += 6;
				j++;
			}
		}break;
		case 2:
		{
			while(ch[j] != '\0')
			{
				c = ch[j] - 32;
				if(x > 120)
				{
					x = 0;
					y++;
				}
				OLED_SetPos(x,y);
				for(i=0;i<8;i++)
					WriteDat(F8X16[c*16+i]);
				OLED_SetPos(x,y+1);
				for(i=0;i<8;i++)
					WriteDat(F8X16[c*16+i+8]);
				x += 8;
				j++;
			}
		}break;
		case 3:
		{
			while(ch[j] != '\0')
			{
				c = ch[j] - 32;
                          
				if(x > 120)
				{
					x = 0;
					y++;
				}
				      OLED_SetPos(x,y);
                                      for(i=0;i<16;i++)
                                        WriteDat(F16X40[c*80+i]);
                                      OLED_SetPos(x,y+1);
                                      for(i=0;i<16;i++)
                                        WriteDat(F16X40[c*80+i+16]);
                                      OLED_SetPos(x,y+2);
                                      for(i=0;i<16;i++)
                                        WriteDat(F16X40[c*80+i+32]);
                                      OLED_SetPos(x,y+3);
                                      for(i=0;i<16;i++)
                                        WriteDat(F16X40[c*80+i+48]);
                                      OLED_SetPos(x,y+4);
                                      for(i=0;i<16;i++)
                                        WriteDat(F16X40[c*80+i+64]);
                                      x += 16;
				j++;
			}
		}break;
	}
}

//--------------------------------------------------------------
// Prototype      : void OLED_ShowCN(unsigned char x, unsigned char y, unsigned char N)
// Calls          : 
// Parameters     : x,y -- ��ʼ������(x:0~127, y:0~7); N:������codetab.h�е�����
// Description    : ��ʾcodetab.h�еĺ���,16*16����
//--------------------------------------------------------------
void OLED_ShowCN(unsigned char x, unsigned char y, unsigned char N)
{
	unsigned char wm=0;
	unsigned int  adder=32*N;
	OLED_SetPos(x , y);
	for(wm = 0;wm < 16;wm++)
	{
		WriteDat(F16x16[adder]);
		adder += 1;
	}
	OLED_SetPos(x,y + 1);
	for(wm = 0;wm < 16;wm++)
	{
		WriteDat(F16x16[adder]);
		adder += 1;
	}
}

//--------------------------------------------------------------
// Prototype      : void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[]);
// Calls          : 
// Parameters     : x0,y0 -- ��ʼ������(x0:0~127, y0:0~7); x1,y1 -- ���Խ���(������)������(x1:1~128,y1:1~8)
// Description    : ��ʾBMPλͼ
//--------------------------------------------------------------
void OLED_DrawBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[])
{
	unsigned int j=0;
	unsigned char x,y;

  if(y1%8==0)
		y = y1/8;
  else
		y = y1/8 + 1;
	for(y=y0;y<y1;y++)
	{
		OLED_SetPos(x0,y);
    for(x=x0;x<x1;x++)
		{
			WriteDat(BMP[j++]);
		}
	}
}
