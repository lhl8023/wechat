#ifndef _ADC_H
#define _ADC_H
#include "stm32f10x.h" 
void ADC_GPIO_Configuration(void);
void ADC_Configuration_CQ1(void);
void NVIC_ADCConfiguration(void);

#endif